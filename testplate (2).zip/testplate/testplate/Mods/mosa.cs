﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class mosa
    {
        public static void MosaMod()
        {
            GorillaLocomotion.Player.Instance.jumpMultiplier = 8.24f;
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 8.24f;
        }
    }
}
