﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Class2
    {
        private static GameObject pointer;

        public static void taggunv2Mod()
        {
            Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.transform.position, GorillaLocomotion.Player.Instance.headCollider.transform.forward, out var Ray);
            pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
            pointer.transform.position = Ray.point;
            UnityEngine.Object.Destroy(pointer.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(pointer.GetComponent<Collider>());
            UnityEngine.Object.Destroy(pointer, Time.deltaTime);
            if (ControllerInputPoller.instance.rightGrab == true)
            {
                GorillaLocomotion.Player.Instance.rightControllerTransform.position = pointer.transform.position;
            }
        }
    }
}
