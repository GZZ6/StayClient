﻿namespace StupidTemplate.Mods
{
    internal class invisplat
    {
    }
}