﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class pbbv
    {
        public static void PBBVWALKMOD()
        {
            GorillaLocomotion.Player.Instance.disableMovement = true;
        }
    }
}
