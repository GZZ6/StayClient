﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Class5
    {

        public static void PlatformsMod()
        { 
        }

            public static bool invisplat = false;
        public static bool stickyplatforms = false;

    }
    }
