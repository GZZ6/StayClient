﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Disconect
    {
        public static void disconnectMODBYGZZ6()
        {
            PhotonNetwork.Disconnect(); //BY.GZZ6
        }

    }
}
