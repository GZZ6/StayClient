﻿using GorillaTag;
using Photon.Pun;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class EndScience
    {
        public static void EndScienceExperementMod()
        {
            if (PhotonNetwork.LocalPlayer == PhotonNetwork.MasterClient)


                ScienceExperimentManager.instance.RestartGame();

            else
            {
                NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=red>]</color> <color=red>YOU ARE NOT MASTER.</color>");
            }
        }
    }
}
