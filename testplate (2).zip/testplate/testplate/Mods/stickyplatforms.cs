﻿namespace StupidTemplate.Mods
{
    internal class stickyplatforms
    {
    }
}