﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.iidk.gorillatag.GZZ6";
        public const string Name = "GZZ6";
        public const string Description = "You are using version 1";
        public const string Version = "1.0.0";
    }
}
